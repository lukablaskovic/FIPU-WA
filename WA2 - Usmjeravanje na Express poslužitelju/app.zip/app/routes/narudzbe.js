import express from 'express';
import { checkArray, pizzaExists } from '../utils/index.js';
const router = express.Router();

// resurs
let narudzbe = [];
let dozvoljene_velicine = ['mala', 'srednja', 'jumbo'];

// endpoint za dodavanje nove narudzbe

router.get('/', (req, res) => {
    res.status(200).json(narudzbe);
});

router.post('/', (req, res) => {
    let nova_narudzba = req.body;

    if (!nova_narudzba) {
        return res.status(400).json({ greska: 'Poslali ste prazan req.body' });
    }

    let id_narudzba = null;

    if (!checkArray(narudzbe)) {
        id_narudzba = 1;
    } else {
        id_narudzba = narudzbe.at(-1)['id'] + 1;
    }

    let narucene_pizze = nova_narudzba.narucene_pizze;

    narucene_pizze.forEach(stavka => {
        if (!pizzaExists(stavka['id_pizza'])) {
            return res.status(400).json({ greska: `Naručena pizza s ID-em ${stavka['id_pizza']} ne postoji.` });
        }

        if (!dozvoljene_velicine.includes(stavka.velicina)) {
            return res.status(400).json({ greska: 'Poslali ste veličinu koja nije podržana.' });
        }
    });

    console.log('Id nove narudžbe je', id_narudzba);

    narudzbe.push({ id: id_narudzba, ...nova_narudzba });
    return res.status(201).json(narudzbe);
});

export default router;
