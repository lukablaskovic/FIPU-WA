import express from 'express';
import { checkArray, same_arrays } from '../utils/index.js';
import { dostupne_pizze } from '../data/pizze_data.js';

const router = express.Router();

let dozvoljeni_kljucevi = ['naziv', 'cijena']; // HTTP zahtjev
const nazivi_dostupnih_pizza = dostupne_pizze.map(pizza => pizza.naziv); //snapshot

// resurs "pizze"
router.get('/', (req, res) => {
    if (!checkArray(dostupne_pizze)) {
        return res.status(500).json({ greska: 'Podacima se ne može pristupiti.' }); // Greška na serveru
    }

    return res.status(200).json(dostupne_pizze); // OK
});

// URL parametar
router.get('/:naziv', (req, res) => {
    if (!checkArray(dostupne_pizze)) {
        return res.status(500).json({ greska: 'Podacima se ne može pristupiti.' }); // Greška na serveru
    }

    let naziv_pizze = req.params.naziv;

    // Greška na strani korisnika
    if (!isNaN(naziv_pizze)) {
        return res.status(400).json({ greska: 'Neispravan podatak.' }); // Greška na klijentskoj strani
    }

    let trazena_pizza = dostupne_pizze.find(pizza => pizza.naziv == naziv_pizze);

    if (trazena_pizza) {
        return res.status(200).json(trazena_pizza);
    }

    return res.status(404).json({ poruka: 'Ne postoji tražena pizza' }); // Ne postoji (Not found)
});

// Podaci se šalju putem req objekta: HTTP tijelo zahtjeva (HTTP body)
router.post('/', (req, res) => {
    if (!req.body) {
        return res.status(400).json({ greska: 'HTTP body je prazan.' });
    }

    let pizza_dodavanje = req.body;

    let kljucevi_pizze = Object.keys(pizza_dodavanje);

    if (!same_arrays(dozvoljeni_kljucevi, kljucevi_pizze)) {
        return res.status(400).json({ greska: 'Kljucevi se ne podudaraju.' });
    }

    // provjera duplikata
    let postojeca = dostupne_pizze.find(pizza => pizza.naziv == pizza_dodavanje.naziv);

    if (postojeca) {
        return res.status(400).json({ greska: `Pizza s nazivom ${pizza_dodavanje.naziv} već postoji!` });
    }

    const novi_id = dostupne_pizze.at(-1)['id'] + 1;
    dostupne_pizze.push({ id: novi_id, ...pizza_dodavanje });
    nazivi_dostupnih_pizza.push(pizza_dodavanje.naziv);

    return res.status(201).json(dostupne_pizze); // Created
});

router.delete('/:naziv', (req, res) => {
    let naziv_brisanje = req.params.naziv;

    if (!isNaN(naziv_brisanje) || !nazivi_dostupnih_pizza.includes(naziv_brisanje)) {
        return res.status(400).json({ greska: 'Neispravan podatak.' }); // Greška na klijentskoj strani
    }

    let pizza_za_brisanje_index = dostupne_pizze.findIndex(pizza => pizza.naziv == naziv_brisanje);

    if (pizza_za_brisanje_index != -1) {
        dostupne_pizze.splice(pizza_za_brisanje_index, 1); //brisanje
        return res.status(204).json(dostupne_pizze);
    } else {
        return res.status(404).json({ poruka: `Ne mogu pronaći pizzu ${naziv_brisanje} za brisanje.` });
    }
});

// zamijenim jednu postojeću pizzu (url parametar) s drugom (http body)
router.put('/:naziv', (req, res) => {
    let naziv_pizza_zamjena = req.params.naziv;

    if (!isNaN(naziv_pizza_zamjena) || !nazivi_dostupnih_pizza.includes(naziv_pizza_zamjena)) {
        return res.status(400).json({ greska: 'Neispravan podatak.' }); // Greška na klijentskoj strani
    }

    let nova_pizza = req.body;
    let nova_pizza_kljucevi = Object.keys(nova_pizza);

    let nova_pizza_cijena = req.body.cijena;

    if (nova_pizza_cijena <= 0) {
        return res.status(400).json({ greska: 'Cijena ne smije biti manja ili jednaka od 0' });
    }

    if (!nova_pizza) {
        return res.status(400).json({ greska: 'Neispravan podatak.' });
    }

    let pizza_zamjena = dostupne_pizze.find(pizza => pizza.naziv == naziv_pizza_zamjena);

    if (!pizza_zamjena) {
        return res.status(404).json({ greska: `Pizza s nazivom ${naziv_pizza_zamjena} ne postoji!` });
    }

    if (!same_arrays(dozvoljeni_kljucevi, nova_pizza_kljucevi)) {
        return res.status(400).json({ greska: 'Kljucevi se ne podudaraju.' });
    }

    let postojeci_id = pizza_zamjena.id; // sačuvali smo id

    let pizza_zamjena_index = dostupne_pizze.indexOf(pizza_zamjena);
    dostupne_pizze.splice(pizza_zamjena_index, 1, { id: postojeci_id, ...nova_pizza });
    return res.json(dostupne_pizze);
});

// Administrator: ruta koja pronalazi po id-u i ažurira cijenu

router.patch('/:id', (req, res) => {
    let pizza_za_patch_id = req.params.id;

    if (isNaN(pizza_za_patch_id)) {
        return res.status(400).json({ greska: 'ID pizze mora biti broj.' });
    }

    if (!req.body) {
        return res.status(400).json({ greska: 'Poslano je prazno tijelo zahtjeva...' });
    }

    // Provjera: postoji li u req.body barem 1 ključ koji je sadržan unutar dozvoljeni_kljucevi

    let patch_podaci = req.body;

    console.log('patch_podaci', patch_podaci);

    let patch_podaci_kljucevi = Object.keys(patch_podaci);

    console.log('patch_podaci_kljucevi', patch_podaci_kljucevi);

    if (!patch_podaci_kljucevi.every(kljuc => dozvoljeni_kljucevi.includes(kljuc))) {
        return res.status(400).json({ greska: 'Poslali ste neispravne kljuceve za azuriranje...' });
    }

    let pizza_patch_index = dostupne_pizze.findIndex(pizza => pizza.id == pizza_za_patch_id);
    if (pizza_patch_index == -1) {
        return res.status(404).json({ greska: `Ne postoji pizza s ID-em ${pizza_za_patch_id}` });
    }

    let pizza_patch = dostupne_pizze[pizza_patch_index];

    Object.assign(pizza_patch, patch_podaci);

    return res.status(200).json(dostupne_pizze);
});

export default router;
