import { dostupne_pizze } from '../data/pizze_data.js';

export function checkArray(array) {
    return Array.isArray(array) && array.length != 0;
}

export function same_arrays(array_1, array_2) {
    if (!checkArray(array_1) || !checkArray(array_2)) {
        return false;
    }

    if (array_1.length != array_2.length) {
        return false;
    }

    return array_1.every(element => array_2.includes(element));
}

// helper funkcija koja provjerava postoji li pizza u "bazi"

export function pizzaExists(id_pizza) {
    return Boolean(dostupne_pizze.find(pizza => pizza.id == id_pizza));
}
